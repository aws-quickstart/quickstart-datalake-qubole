#!/bin/bash

rm assets/assets.zip
zip -r assets.zip assets/
mv assets.zip assets/
