from setuptools import setup

setup(
    name='qubole-quickstart',
    version='1.0',
)
